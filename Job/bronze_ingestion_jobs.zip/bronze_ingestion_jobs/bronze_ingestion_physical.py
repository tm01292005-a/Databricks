# Databricks notebook source
# DBTITLE 1,物理収集メイン処理
# ================================
# セットアップ：インポートと設定
# ================================
import sys
import os
import re

# 現在のノートブックのディレクトリを取得
notebook_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
notebook_dir = os.path.dirname(notebook_path)

# プロジェクトルート（親ディレクトリ）を取得
project_root = os.path.dirname(notebook_dir)

# sys.pathに追加（プロジェクトルートを追加することで utilities にアクセス可能）
if project_root not in sys.path:
    sys.path.append(project_root)
from utilities.jdbc_reader import get_connection
from utilities.metadata_reader import get_mask_rules
from utilities.masking_sql_builder import build_select_sql
from utilities.schema_query_builder import build_column_query

from datetime import datetime
from pyspark.sql import DataFrame

# 設定
INGESTION_CONFIG_TABLE = "admin.ingestion_config"
TARGET_CATALOG = "workspace"
TARGET_SCHEMA = "default"

# ================================
# メトリクス記録用の変数
# ================================
success_metrics = []
failure_metrics = []

# ================================
# メイン処理：テーブルの取り込み
# ================================
print("=" * 80)
print("物理収集処理を開始します")
print("=" * 80)

# 設定テーブルから収集対象を取得
configs = spark.read.table(INGESTION_CONFIG_TABLE).collect()
total_tables = len(configs)

print(f"\n収集対象テーブル数: {total_tables}")
print("-" * 80)

# 各テーブルを処理
for idx, cfg in enumerate(configs, 1):
    table_name = f"{cfg.source_system}.{cfg.schema_name}.{cfg.table_name}"
    target_table = f"{TARGET_CATALOG}.{TARGET_SCHEMA}.bronze_{cfg.target_name}"
    
    print(f"\n[{idx}/{total_tables}] 処理中: {table_name} -> {target_table}")
    
    start_time = datetime.now()
    
    try:
        # 1. JDBC接続情報を取得
        conn = get_connection(cfg.source_system)
        db_type = conn["db_type"]
        jdbc_url = conn["jdbc_url"]
        
        properties = {
            "user": conn["user"],
            "password": conn["password"]
        }
        
        # 2. カラム一覧を取得
        column_query = build_column_query(
            db_type,
            cfg.schema_name,
            cfg.table_name
        )
        
        columns_df = (
            spark.read
            .format("jdbc")
            .option("url", jdbc_url)
            .option("user", properties["user"])
            .option("password", properties["password"])
            .option("query", column_query)
            .load()
        )
        
        columns = [r["column_name"] for r in columns_df.collect()]
        print(f"  カラム数: {len(columns)}")
        
        # 3. マスキングルールを取得して適用
        mask_rules = get_mask_rules(cfg.table_name)
        masked_columns = [rule["column_name"] for rule in mask_rules]
        
        if masked_columns:
            print(f"  マスク対象カラム: {', '.join(masked_columns)}")
        
        # 4. マスキング適用SQLを構築
        sql_text = build_select_sql(
            db_type,
            cfg.schema_name,
            cfg.table_name,
            columns,
            mask_rules
        )
        
        # 5. データを読み込み
        df = (
            spark.read
            .jdbc(
                url=jdbc_url,
                table=f"({sql_text}) src",
                properties=properties
            )
        )
        
        row_count = df.count()
        print(f"  読み込み行数: {row_count:,}")
        
        # 6. Deltaテーブルとして保存
        df.write.mode("overwrite").saveAsTable(target_table)
        
        # 実行時間計算
        duration = (datetime.now() - start_time).total_seconds()
        
        print(f"  ✓ 成功 (実行時間: {duration:.2f}秒)")
        
        # メトリクス記録
        success_metrics.append({
            "source_table": table_name,
            "target_table": target_table,
            "row_count": row_count,
            "duration_seconds": duration,
            "masked_columns": len(masked_columns),
            "timestamp": datetime.now()
        })
        
    except Exception as e:
        duration = (datetime.now() - start_time).total_seconds()
        error_msg = str(e)
        
        print(f"  ✗ 失敗: {error_msg}")
        
        # エラーメトリクス記録
        failure_metrics.append({
            "source_table": table_name,
            "target_table": target_table,
            "error_message": error_msg,
            "duration_seconds": duration,
            "timestamp": datetime.now()
        })
        
        # 個別テーブルの失敗は全体を止めない
        continue

# ================================
# 実行結果サマリー表示
# ================================
print("\n" + "=" * 80)
print("物理収集処理が完了しました")
print("=" * 80)

print(f"\n【実行結果サマリー】")
print(f"  総テーブル数: {total_tables}")
print(f"  成功: {len(success_metrics)}")
print(f"  失敗: {len(failure_metrics)}")

if success_metrics:
    total_rows = sum(m["row_count"] for m in success_metrics)
    total_duration = sum(m["duration_seconds"] for m in success_metrics)
    print(f"  総取り込み行数: {total_rows:,}")
    print(f"  総実行時間: {total_duration:.2f}秒")

if failure_metrics:
    print(f"\n【失敗したテーブル】")
    for fm in failure_metrics:
        print(f"  - {fm['source_table']}")
        print(f"    エラー: {fm['error_message'][:100]}...")

# 成功したテーブルのリスト表示
if success_metrics:
    print(f"\n【成功したテーブル】")
    for sm in success_metrics:
        print(f"  - {sm['target_table']} ({sm['row_count']:,} 行)")

print("\n" + "=" * 80)