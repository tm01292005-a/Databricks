def build_column_query(
        db_type,
        schema_name,
        table_name):
    """
    指定されたスキーマとデータベースタイプ内の指定されたテーブルの列名を返すクエリを構築します。
    @param db_type: データベースタイプ
    @param schema_name: スキーマ名
    @param table_name: テーブル名
    @return: 指定されたスキーマとデータベースタイプ内の指定されたテーブルの列名を返すクエリ
    @reraises Exception: サポートされていないデータベースタイプの場合
    """
    if db_type == "POSTGRES":
        return f"""
        SELECT
            column_name
        FROM information_schema.columns
        WHERE table_schema = '{schema_name}'
          AND table_name = '{table_name}'
        ORDER BY ordinal_position
        """

    elif db_type == "ORACLE":
        return f"""
        SELECT
            COLUMN_NAME AS column_name
        FROM ALL_TAB_COLUMNS
        WHERE OWNER = UPPER('{schema_name}')
          AND TABLE_NAME = UPPER('{table_name}')
        ORDER BY COLUMN_ID
        """

    elif db_type == "SQLSERVER":
        return f"""
        SELECT
            COLUMN_NAME AS column_name
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = '{schema_name}'
          AND TABLE_NAME = '{table_name}'
        ORDER BY ORDINAL_POSITION
        """

    raise Exception(
        f"Unsupported DB Type : {db_type}"
    )


def build_all_tables_query(db_type):
    """
    データベースから全テーブル（システムテーブルを除く）を取得するクエリを構築します。
    @param db_type: データベースタイプ（POSTGRES/ORACLE/SQLSERVER）
    @return: スキーマ名とテーブル名を返すクエリ
    @raises Exception: サポートされていないデータベースタイプの場合
    """
    if db_type == "POSTGRES":
        return """
        SELECT
            table_schema AS schema_name,
            table_name
        FROM information_schema.tables
        WHERE table_type = 'BASE TABLE'
          AND table_schema NOT IN ('information_schema', 'pg_catalog')
        ORDER BY table_schema, table_name
        """

    elif db_type == "ORACLE":
        return """
        SELECT
            OWNER AS schema_name,
            TABLE_NAME AS table_name
        FROM ALL_TABLES
        WHERE OWNER NOT IN (
            'SYS', 'SYSTEM', 'OUTLN', 'DIP', 'ORACLE_OCM', 
            'DBSNMP', 'APPQOSSYS', 'WMSYS', 'EXFSYS', 'CTXSYS', 
            'XDB', 'ANONYMOUS', 'MDSYS', 'ORDDATA', 'ORDPLUGINS', 
            'ORDSYS', 'SI_INFORMTN_SCHEMA', 'OLAPSYS'
        )
        ORDER BY OWNER, TABLE_NAME
        """

    elif db_type == "SQLSERVER":
        return """
        SELECT
            TABLE_SCHEMA AS schema_name,
            TABLE_NAME AS table_name
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_TYPE = 'BASE TABLE'
          AND TABLE_SCHEMA NOT IN ('information_schema', 'sys')
        ORDER BY TABLE_SCHEMA, TABLE_NAME
        """

    raise Exception(
        f"Unsupported DB Type : {db_type}"
    )