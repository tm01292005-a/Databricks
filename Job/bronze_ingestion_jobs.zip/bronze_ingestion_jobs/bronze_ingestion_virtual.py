# Databricks notebook source
# DBTITLE 1,仮想統合メイン処理
# ================================
# 仮想統合：外部DBテーブルを参照するビュー作成
# ================================
# このノートブックは1回実行すればOK。
# 作成されたビューは、クエリ時に外部DBから最新データをリアルタイムで取得します。
# 
# 【動作】
# 1. admin.jdbc_connectionsから全データベースを取得
# 2. 各データベースから全テーブルを自動検出
# 3. admin.ingestion_configに記載されている物理収集対象テーブルを除外
# 4. 残りの全テーブルにビューを作成
# ================================

import sys
import os
import re

# 現在のノートブックのディレクトリを取得
notebook_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
notebook_dir = os.path.dirname(notebook_path)

# プロジェクトルート（親ディレクトリ）を取得
project_root = os.path.dirname(notebook_dir)

# sys.pathに追加（プロジェクトルートを追加することで utilities にアクセス可能）
if project_root not in sys.path:
    sys.path.append(project_root)

from utilities.jdbc_reader import get_connection
from utilities.metadata_reader import get_mask_rules
from utilities.masking_sql_builder import build_select_sql
from utilities.schema_query_builder import build_column_query, build_all_tables_query

from datetime import datetime

# 設定
JDBC_CONNECTIONS_TABLE = "admin.jdbc_connections"
INGESTION_CONFIG_TABLE = "admin.ingestion_config"
TARGET_CATALOG = "workspace"
TARGET_SCHEMA = "default"

# ================================
# メトリクス記録用の変数
# ================================
success_views = []
failure_views = []
skipped_tables = []

# ================================
# メイン処理：ビューの作成
# ================================
print("=" * 80)
print("仮想統合：ビュー作成処理を開始します")
print("=" * 80)
print("\n【動作】")
print("  1. 全データベースから全テーブルを自動検出")
print("  2. 物理収集対象（ingestion_configに記載）を除外")
print("  3. 残りの全テーブルにビューを作成")
print("  4. ビューはクエリ時に外部DBから最新データを取得")
print("-" * 80)

# 1. 物理収集対象テーブルのセットを作成（除外リスト）
print("\n[Step 1] 物理収集対象テーブルを読み込み中...")
try:
    physical_configs = spark.read.table(INGESTION_CONFIG_TABLE).collect()
    physical_table_set = {
        (cfg.source_system, cfg.schema_name.lower(), cfg.table_name.lower()) 
        for cfg in physical_configs
    }
    print(f"  物理収集対象: {len(physical_table_set)}テーブル（仮想統合から除外）")
except Exception as e:
    print(f"  警告: ingestion_configが見つかりません。全テーブルをビュー化します。")
    physical_table_set = set()

# 2. 全データベースを取得
print("\n[Step 2] 接続先データベースを読み込み中...")
all_databases = spark.read.table(JDBC_CONNECTIONS_TABLE).collect()
print(f"  対象データベース数: {len(all_databases)}")
print("-" * 80)

# 3. 各データベースから全テーブルを取得してビューを作成
total_discovered = 0

for db_idx, db_config in enumerate(all_databases, 1):
    source_system = db_config.source_system
    print(f"\n[Database {db_idx}/{len(all_databases)}] {source_system} を処理中...")
    
    try:
        # JDBC接続情報を取得
        conn = get_connection(source_system)
        db_type = conn["db_type"]
        jdbc_url = conn["jdbc_url"]
        user = conn["user"]
        password = conn["password"]
        
        # 全テーブル取得クエリを構築
        all_tables_query = build_all_tables_query(db_type)
        
        # 全テーブルを取得
        all_tables_df = (
            spark.read
            .format("jdbc")
            .option("url", jdbc_url)
            .option("user", user)
            .option("password", password)
            .option("query", all_tables_query)
            .load()
        )
        
        all_tables = all_tables_df.collect()
        print(f"  検出されたテーブル数: {len(all_tables)}")
        total_discovered += len(all_tables)

        
        # 各テーブルに対してビューを作成
        for table in all_tables:
            schema_name = table.schema_name
            table_name = table.table_name
            full_table_name = f"{source_system}.{schema_name}.{table_name}"
            
            # 物理収集対象かチェック（除外）
            if (source_system, schema_name.lower(), table_name.lower()) in physical_table_set:
                skipped_tables.append(full_table_name)
                continue
            
            # ターゲットビュー名を生成（スキーマ名_テーブル名）
            target_view_name = re.sub(r'[^a-z0-9_]', '_', f"{schema_name}_{table_name}".lower())
            target_view = f"{TARGET_CATALOG}.{TARGET_SCHEMA}.bronze_{target_view_name}"
            
            start_time = datetime.now()
            
            try:
                # カラム一覧を取得
                column_query = build_column_query(db_type, schema_name, table_name)
                
                columns_df = (
                    spark.read
                    .format("jdbc")
                    .option("url", jdbc_url)
                    .option("user", user)
                    .option("password", password)
                    .option("query", column_query)
                    .load()
                )
                
                columns = [r["column_name"] for r in columns_df.collect()]
                
                # マスキングルールを取得して適用
                mask_rules = get_mask_rules(table_name)
                masked_columns = [rule["column_name"] for rule in mask_rules]
                
                # マスキング適用SQL文を構築
                masked_sql = build_select_sql(
                    db_type,
                    schema_name,
                    table_name,
                    columns,
                    mask_rules
                )
                
                # SQLインジェクション対策：シングルクォートをエスケープ
                masked_sql_escaped = masked_sql.replace("'", "''")
                
                # ビューを作成
                view_sql = f"""
                CREATE OR REPLACE VIEW {target_view} AS
                SELECT * FROM (
                    SELECT * FROM jdbc(
                        url => '{jdbc_url}',
                        query => '{masked_sql_escaped}',
                        properties => map('user', '{user}', 'password', '{password}')
                    )
                )
                """
                
                spark.sql(view_sql)
                
                duration = (datetime.now() - start_time).total_seconds()
                
                # メトリクス記録
                success_views.append({
                    "source_table": full_table_name,
                    "target_view": target_view,
                    "masked_columns": len(masked_columns),
                    "duration_seconds": duration,
                    "timestamp": datetime.now()
                })
                
            except Exception as e:
                duration = (datetime.now() - start_time).total_seconds()
                error_msg = str(e)
                
                # エラーメトリクス記録
                failure_views.append({
                    "source_table": full_table_name,
                    "target_view": target_view,
                    "error_message": error_msg,
                    "duration_seconds": duration,
                    "timestamp": datetime.now()
                })
                
                # 個別テーブルの失敗は全体を止めない
                continue
        
        print(f"  {source_system}: 成功 {len([v for v in success_views if source_system in v['source_table']])} / "
              f"失敗 {len([v for v in failure_views if source_system in v['source_table']])} / "
              f"スキップ {len([t for t in skipped_tables if source_system in t])}")
        
    except Exception as e:
        print(f"  ✗ データベース接続エラー: {str(e)}")
        continue

# ================================
# 実行結果サマリー表示
# ================================
print("\n" + "=" * 80)
print("仮想統合：ビュー作成処理が完了しました")
print("=" * 80)

print(f"\n【実行結果サマリー】")
print(f"  全データベース数: {len(all_databases)}")
print(f"  検出された総テーブル数: {total_discovered}")
print(f"  物理収集対象（スキップ）: {len(skipped_tables)}")
print(f"  ビュー作成成功: {len(success_views)}")
print(f"  ビュー作成失敗: {len(failure_views)}")

if success_views:
    total_duration = sum(v["duration_seconds"] for v in success_views)
    masked_view_count = len([v for v in success_views if v['masked_columns'] > 0])
    print(f"  総実行時間: {total_duration:.2f}秒")
    print(f"  マスキング適用ビュー数: {masked_view_count}")

if failure_views:
    print(f"\n【失敗したテーブル（最初の10件）】")
    for fv in failure_views[:10]:
        print(f"  - {fv['source_table']}")
        print(f"    エラー: {fv['error_message'][:100]}...")
    if len(failure_views) > 10:
        print(f"  ... 他 {len(failure_views) - 10} 件")

if skipped_tables:
    print(f"\n【物理収集対象としてスキップ（最初の10件）】")
    for st in skipped_tables[:10]:
        print(f"  - {st}")
    if len(skipped_tables) > 10:
        print(f"  ... 他 {len(skipped_tables) - 10} 件")

# 成功したビューのリスト表示（最初の20件）
if success_views:
    print(f"\n【作成されたビュー（最初の20件）】")
    for sv in success_views[:20]:
        mask_info = f" [マスク: {sv['masked_columns']}カラム]" if sv['masked_columns'] > 0 else ""
        print(f"  - {sv['target_view']}{mask_info}")
    if len(success_views) > 20:
        print(f"  ... 他 {len(success_views) - 20} 件")

print("\n" + "=" * 80)
print("使い方：")
print("  作成されたビューは、通常のテーブルと同じようにクエリできます。")
print("  例: SELECT * FROM workspace.default.bronze_public_customers")
print("  ")
print("  クエリを実行するたびに、外部DBから最新データを取得します。")
print("  このノートブックの定期実行は不要です。")
print("  ")
print("注意：")
print("  - ビュー名は「bronze_<スキーマ名>_<テーブル名>」形式です")
print("  - 物理収集対象（ingestion_configに記載）は自動除外されます")
print("=" * 80)