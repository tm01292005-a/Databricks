from pyspark.sql import functions as F

# マスキングルール管理テーブル
MASKING_RULE_TABLE = "admin.masking_rules"

def get_mask_rules(table_name):
    """
    指定されたテーブル名に対するマスキングルールの一覧を返す。
    @param table_name: マスキングルールを取得したいテーブル名
    @return: マスキングルールの一覧
    """
    return (
        spark.read.table(MASKING_RULE_TABLE)
        .filter(F.col("table_name") == table_name)
        .collect()
    )
