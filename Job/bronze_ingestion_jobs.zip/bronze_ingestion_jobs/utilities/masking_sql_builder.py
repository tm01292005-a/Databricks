from .db_mask_functions import (
    postgres_mask,
    oracle_mask,
    sqlserver_mask
)

def build_select_sql(
        db_type,
        schema_name,
        table_name,
        columns,
        mask_rules):
    """
    SELECT文を生成する関数
    @param db_type: DBMS種別
    @param schema_name: スキーマ名
    @param table_name: テーブル名
    @param columns: SELECT句のカラム名リスト
    @param mask_rules: マスクルールリスト
    @return: SELECT文
    @raise ValueError: db_typeがサポートされていない場合
    @raise ValueError: mask_rulesがカラム名に対応していない場合
    @raise ValueError: カラム名が重複している場合
    @raise ValueError: カラム名がテーブルに存在しない場合
    @raise ValueError: カラム名が重複している場合
    @raise ValueError: mask_typeがサポートされていない場合
    """
    rule_dict = {
        r["column_name"]: r["mask_type"]
        for r in mask_rules
    }

    select_exprs = []

    for column_name in columns:
        mask_type = rule_dict.get(column_name)
        if mask_type is None:
            select_exprs.append(column_name)
            continue

        if db_type == "POSTGRES":
            select_exprs.append(
                postgres_mask(
                    column_name,
                    mask_type
                )
            )

        elif db_type == "ORACLE":
            select_exprs.append(
                oracle_mask(
                    column_name,
                    mask_type
                )
            )

        elif db_type == "SQLSERVER":
            select_exprs.append(
                sqlserver_mask(
                    column_name,
                    mask_type
                )
            )

    return f"""
        SELECT
            {",".join(select_exprs)}
        FROM {schema_name}.{table_name}
    """
