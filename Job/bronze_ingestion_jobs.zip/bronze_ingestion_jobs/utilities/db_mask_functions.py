def postgres_mask(column_name, mask_type):
    """
    マスク化するカラム名を返す(PostgreSQL)
    Args:
        column_name (str): マスク化するカラム名
        mask_type (str): マスク化するタイプ(HASH, NULL, MASK)
    Returns:
        str: マスク化されたカラム名
    """
    if mask_type == "HASH": # HASH値でマスク化
        return f"md5(CAST({column_name} AS TEXT)) AS {column_name}"

    if mask_type == "NULL": # NULL値でマスク化
        return f"NULL AS {column_name}"

    if mask_type == "MASK": # *でマスク化
        return f"REPEAT('*', LENGTH(CAST({column_name} AS TEXT))) AS {column_name}"

    return column_name


def oracle_mask(column_name, mask_type):
    """
    マスク化するカラム名を返す(OracleDB)
    Args:
        column_name (str): マスク化するカラム名
        mask_type (str): マスク化するタイプ(HASH, NULL, MASK)
    Returns:
        str: マスク化されたカラム名
    """
    if mask_type == "HASH": # HASH値でマスク化
        return (
            f"STANDARD_HASH("
            f"{column_name},'SHA256'"
            f") AS {column_name}"
        )

    if mask_type == "NULL": # NULL値でマスク化
        return f"NULL AS {column_name}"

    if mask_type == "MASK": # *でマスク化
        return f"LPAD('*', LENGTH({column_name}), '*') AS {column_name}"

    return column_name


def sqlserver_mask(column_name, mask_type):
    """
    マスク化するカラム名を返す(SQL Server)
    Args:
        column_name (str): マスク化するカラム名
        mask_type (str): マスク化するタイプ(HASH, NULL, MASK)
    Returns:
        str: マスク化されたカラム名
    """
    if mask_type == "HASH":

        return (
            f"CONVERT(VARCHAR(64),"
            f"HASHBYTES('SHA2_256',"
            f"CAST({column_name} AS NVARCHAR(MAX))),2)"
            f" AS {column_name}"
        )

    if mask_type == "NULL":
        return f"NULL AS {column_name}"

    if mask_type == "MASK": # *でマスク化
        return f"REPLICATE('*', LEN(CAST({column_name} AS NVARCHAR(MAX)))) AS {column_name}"

    return column_name