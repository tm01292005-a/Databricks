# JDBC接続情報テーブル
JDBC_CONNECTIONS_TABLE = "admin.jdbc_connections"

def get_connection(source_system):
    """
    指定されたソースシステムの接続情報を含む辞書を返す
    @param source_system: 連携元ソースシステム名
    @return: 指定されたソースシステムの接続情報を含む辞書
    @raises ValueError: 指定されたソースシステムがテーブルに見つからない場合
    @raises Exception: テーブルの読み取り中にエラーが発生した場合
    """
    row = (
        spark.read.table(JDBC_CONNECTIONS_TABLE)
        .filter(
            f"source_system='{source_system}'"
        )
        .first()
    )

    if row is None:
        raise ValueError(f"Source system '{source_system}' not found in {JDBC_CONNECTIONS_TABLE}")

    return {
        "db_type": row.db_type,
        "jdbc_url": row.jdbc_url,
        "user": dbutils.secrets.get(
            row.secret_scope,
            "username"
        ),
        "password": dbutils.secrets.get(
            row.secret_scope,
            "password"
        )
    }
