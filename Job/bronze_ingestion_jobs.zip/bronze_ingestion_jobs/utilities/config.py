# マスキング定義テーブル
MASK_RULE_TABLE = "admin.masking_rules"
# 収集対象管理テーブル
INGESTION_CONFIG_TABLE = "admin.ingestion_config"
# JDBC接続情報テーブル
JDBC_CONNECTION_TABLE = "admin.jdbc_connections"
